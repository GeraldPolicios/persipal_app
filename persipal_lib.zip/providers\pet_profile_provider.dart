// lib/providers/pet_profile_provider.dart
//
// Manages FullPetProfile CRUD.
//
// Storage:
//   • Hive = primary/offline-first storage
//   • Firestore = background synchronization
//
// Vaccination/reminder relationship:
//   • A vaccination may have one linked Care Reminder.
//   • Completing a vaccination completes the linked reminder,
//     but NEVER deletes it.
//   • Completed reminders remain in the Done tab.
//   • Vaccination history is NEVER overwritten.
//   • A completed dose can create a new completed record and,
//     optionally, a new reminder for its next dose.
//   • Recurring vaccination series creates independent records
//     and independent reminders for every dose.

import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';

import '../models/pet_extended_models.dart';
import '../models/reminder_item_model.dart';
import '../services/activity_log_service.dart';
import '../services/auth_service.dart';
import '../services/connectivity_service.dart';
import '../services/local_storage_service.dart';
import '../services/pet_photo_service.dart';
import '../services/reward_service.dart';
import 'reminder_provider.dart';

const String _boxName = 'full_pet_profiles';
const int _maxProfiles = 10;
const String _deletedProfilesKey = '__deleted_profile_ids__';

class PetProfileProvider extends ChangeNotifier {
  PetProfileProvider._();

  static final PetProfileProvider instance = PetProfileProvider._();

  final Uuid _uuid = const Uuid();

  final AuthService _auth = AuthService.instance;
  final ActivityLogService _log = ActivityLogService.instance;
  final ConnectivityService _connectivity = ConnectivityService.instance;
  final LocalStorageService _local = LocalStorageService.instance;

  List<FullPetProfile> _profiles = [];
  final Set<String> _deletedProfileIds = <String>{};

  bool _loading = false;

  bool _initialized = false;

  // ─────────────────────────────────────────────────────────────────────────
  // Getters
  // ─────────────────────────────────────────────────────────────────────────

  List<FullPetProfile> get profiles => List.unmodifiable(_profiles);

  bool get loading => _loading;

  bool get canAdd => _profiles.length < _maxProfiles;

  int get count => _profiles.length;

  Box<String> get _box => Hive.box<String>(_boxName);

  // ─────────────────────────────────────────────────────────────────────────
  // Initialization
  // ─────────────────────────────────────────────────────────────────────────

  Future<void> init() async {
    if (_initialized) return;

    _initialized = true;

    await Hive.openBox<String>(_boxName);

    await _loadFromHive();

    if (_auth.isAuthenticated && _auth.accountSyncAllowed) {
      unawaited(_downloadFromCloud());
      unawaited(_flushPendingOps());
    }

    _auth.addListener(_onAuthChanged);
    _connectivity.addListener(_onConnectivityChanged);
  }

  @override
  void dispose() {
    _auth.removeListener(_onAuthChanged);
    _connectivity.removeListener(_onConnectivityChanged);
    super.dispose();
  }

  void _onAuthChanged() {
    if (_auth.isAuthenticated && _auth.accountSyncAllowed) {
      unawaited(_downloadFromCloud());
      unawaited(_flushPendingOps());
    }
  }

  void _onConnectivityChanged() {
    if (_connectivity.isOnline &&
        _auth.isAuthenticated &&
        _auth.accountSyncAllowed) {
      unawaited(_downloadFromCloud());
      unawaited(_flushPendingOps());
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Hive
  // ─────────────────────────────────────────────────────────────────────────

  Future<void> _loadFromHive() async {
    _loading = true;
    notifyListeners();

    try {
      final loaded = <FullPetProfile>[];

      _deletedProfileIds
        ..clear()
        ..addAll(_readDeletedProfileIds());

      for (final key in _box.keys) {
        if (key == _deletedProfilesKey) continue;
        final raw = _box.get(key);
        if (raw == null) continue;
        try {
          final decoded = jsonDecode(raw) as Map<String, dynamic>;

          loaded.add(
            FullPetProfile.fromMap(decoded),
          );
        } catch (e) {
          debugPrint(
            'PetProfileProvider: failed to decode profile: $e',
          );
        }
      }

      loaded.sort(
        (a, b) => a.createdAt.compareTo(b.createdAt),
      );

      _profiles = loaded;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Set<String> _readDeletedProfileIds() {
    final raw = _box.get(_deletedProfilesKey);
    if (raw == null) return <String>{};

    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) return decoded.whereType<String>().toSet();
    } catch (_) {
      // A malformed tombstone must not prevent valid pet profiles from
      // loading. It is replaced on the next deletion.
    }
    return <String>{};
  }

  Future<void> _saveDeletedProfileIds() async {
    if (_deletedProfileIds.isEmpty) {
      await _box.delete(_deletedProfilesKey);
      return;
    }
    await _box.put(
      _deletedProfilesKey,
      jsonEncode(_deletedProfileIds.toList()),
    );
  }

  Future<void> _saveToHive(
    FullPetProfile profile,
  ) async {
    await _box.put(
      profile.id,
      jsonEncode(profile.toMap()),
    );
  }

  Future<void> _deleteFromHive(
    String id,
  ) async {
    await _box.delete(id);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Firestore
  // ─────────────────────────────────────────────────────────────────────────

  CollectionReference<Map<String, dynamic>>? get _collection {
    if (!_auth.isAuthenticated) {
      return null;
    }

    final userId = _auth.userId;

    if (userId.isEmpty) {
      return null;
    }

    return FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('full_pet_profiles');
  }

  Future<void> _uploadToCloud(
    FullPetProfile profile,
  ) async {
    final collection = _collection;

    if (collection == null) {
      // Not authenticated — nothing to sync yet; Hive already has it.
      return;
    }

    if (!_connectivity.isOnline) {
      await _local.queuePendingOp('pet_profile:${profile.id}');
      return;
    }

    try {
      await collection.doc(profile.id).set(
            profile.toMap(),
            SetOptions(merge: true),
          );
    } catch (e) {
      debugPrint(
        'PetProfileProvider: cloud upload failed: $e',
      );
      await _local.queuePendingOp('pet_profile:${profile.id}');
    }
  }

  Future<void> _deleteFromCloud(
    String id,
  ) async {
    final collection = _collection;

    if (collection == null) {
      return;
    }

    if (!_connectivity.isOnline) {
      await _local.queuePendingOp('delete_pet_profile:$id');
      return;
    }

    try {
      await collection.doc(id).delete();
    } catch (e) {
      debugPrint(
        'PetProfileProvider: cloud delete failed: $e',
      );
      await _local.queuePendingOp('delete_pet_profile:$id');
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Pending-ops retry (shares LocalStorageService's pending-sync queue with
  // FirebaseSyncService — only 'pet_profile'/'delete_pet_profile' tokens are
  // this provider's own; any other prefix belongs to a different owner and
  // is left untouched, never removed here).
  // ─────────────────────────────────────────────────────────────────────────

  Future<void> _flushPendingOps() async {
    if (!_auth.isAuthenticated || !_connectivity.isOnline) return;

    final collection = _collection;
    if (collection == null) return;

    final tokens = await _local.fetchPendingOps();
    if (tokens.isEmpty) return;

    for (final token in tokens) {
      final parts = token.split(':');
      if (parts.length < 2) continue;
      final type = parts[0];
      final id = parts[1];

      if (type != 'pet_profile' && type != 'delete_pet_profile') continue;

      try {
        if (type == 'pet_profile') {
          final profile = _getById(id);
          if (profile == null) {
            // Profile no longer exists locally — drop the stale token.
            await _local.removePendingOp(token);
            continue;
          }
          await collection
              .doc(id)
              .set(profile.toMap(), SetOptions(merge: true));
        } else {
          await collection.doc(id).delete();
        }
        // Only remove on confirmed success — a failure here leaves the
        // token in place for the next connectivity/auth trigger, without
        // re-queuing a duplicate (that's what caused a token to vanish
        // without actually completing, if it were re-added and then
        // unconditionally removed in the same pass).
        await _local.removePendingOp(token);
      } catch (_) {
        // Leave token in queue for next attempt.
      }
    }
  }

  Future<void> _downloadFromCloud() async {
    try {
      final collection = _collection;

      if (collection == null) {
        return;
      }

      final snapshot = await collection.get();

      if (snapshot.docs.isEmpty) {
        await PetPhotoService.instance.restorePhotosForPetIds(
          _profiles.map((profile) => profile.id),
        );
        return;
      }

      final localMap = <String, FullPetProfile>{
        for (final profile in _profiles) profile.id: profile,
      };

      for (final doc in snapshot.docs) {
        try {
          final cloudProfile = FullPetProfile.fromMap(doc.data());

          if (_deletedProfileIds.contains(cloudProfile.id)) {
            // A local deletion wins over a stale cloud document, including
            // after sign-out while the delete is still waiting to sync.
            continue;
          }

          final localProfile = localMap[cloudProfile.id];

          if (localProfile == null ||
              cloudProfile.updatedAt.isAfter(localProfile.updatedAt)) {
            localMap[cloudProfile.id] = cloudProfile;

            await _saveToHive(cloudProfile);
          }
        } catch (e) {
          debugPrint(
            'PetProfileProvider: invalid cloud profile: $e',
          );
        }
      }

      _profiles = localMap.values.toList()
        ..sort(
          (a, b) => a.createdAt.compareTo(b.createdAt),
        );

      await PetPhotoService.instance.restorePhotosForPetIds(
        _profiles.map((profile) => profile.id),
        uploadMissingLocalPhotosFor: snapshot.docs.map((doc) => doc.id),
      );
      notifyListeners();
    } catch (e) {
      debugPrint(
        'PetProfileProvider: cloud download failed: $e',
      );
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Create profile
  // ─────────────────────────────────────────────────────────────────────────

  Future<FullPetProfile?> createProfile({
    required String name,
    required String breed,
    required int avatarColorValue,
    String birthday = '',
    String gender = 'Female',
  }) async {
    if (!canAdd) {
      return null;
    }

    final base = FullPetProfile.create(
      id: _uuid.v4(),
      name: name.trim(),
      breed: kPersianBreed, // Persian-only app: the breed can't vary
      avatarColorValue: avatarColorValue,
      birthday: birthday,
      gender: gender,
    );

    var achievements = await _unlockAndLog(
      List.of(kDefaultAchievements),
      AchievementType.firstProfile,
      1,
      base.name,
    );

    achievements = await _checkProfileComplete(
      base.copyWith(achievements: achievements),
    );

    final profile = base.copyWith(
      achievements: achievements,
    );

    _profiles.add(profile);

    notifyListeners();

    await _saveToHive(profile);

    unawaited(
      _uploadToCloud(profile),
    );

    await _log.logProfileAdded(
      profile.name,
    );

    return profile;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Update profile
  // ─────────────────────────────────────────────────────────────────────────

  Future<void> updateDetails(
    FullPetProfile updated,
  ) async {
    final index = _profiles.indexWhere(
      (p) => p.id == updated.id,
    );

    if (index < 0) {
      return;
    }

    final synchronizedWeight =
        updated.latestGrowthEntry?.weightKg.toString() ?? updated.weightKg;
    final saved = updated.copyWith(
      weightKg: synchronizedWeight,
      achievements: await _checkProfileComplete(updated),
      updatedAt: DateTime.now(),
    );

    _profiles[index] = saved;

    notifyListeners();

    await _saveToHive(saved);

    unawaited(
      _uploadToCloud(saved),
    );

    await _log.logProfileUpdated(
      saved.name,
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Delete profile
  // ─────────────────────────────────────────────────────────────────────────

  Future<void> deleteProfile(
    String id,
  ) async {
    final index = _profiles.indexWhere(
      (p) => p.id == id,
    );

    if (index < 0) {
      return;
    }

    final profile = _profiles[index];

    _profiles.removeAt(index);

    notifyListeners();

    _deletedProfileIds.add(id);
    await _saveDeletedProfileIds();

    await _deleteFromHive(id);

    unawaited(
      _deleteFromCloud(id),
    );

    await PetPhotoService.instance.deletePhotoForPet(id);

    await _log.logProfileDeleted(
      profile.name,
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Growth tracker
  // ─────────────────────────────────────────────────────────────────────────

  Future<void> addGrowthEntry(
    String petId,
    GrowthEntry entry,
  ) async {
    final profile = _getById(petId);

    if (profile == null) return;

    // Reward points: a recorded weigh-in is a real-pet care activity (once
    // per entry id).
    unawaited(RewardService.instance
        .awardOnce('growth:${entry.id}', RewardService.growthPoints));

    final entries = [
      ...profile.growthEntries,
      entry,
    ]..sort(
        (a, b) => a.recordedAt.compareTo(
          b.recordedAt,
        ),
      );

    var achievements = await _unlockAndLog(
      profile.achievements,
      AchievementType.growthMilestone,
      entries.length,
      profile.name,
    );

    achievements = await _unlockAndLog(
      achievements,
      AchievementType.firstWeighIn,
      entries.length,
      profile.name,
    );

    final careDays = _addDay(
      profile.careActivityDays,
      _dayKey(entry.recordedAt),
    );

    achievements = await _unlockAndLog(
      achievements,
      AchievementType.weekOfCare,
      careDays.length,
      profile.name,
    );

    await updateDetails(
      profile.copyWith(
        growthEntries: entries,
        achievements: achievements,
        careActivityDays: careDays,
      ),
    );

    // Activity History — logged only after the entry is actually saved
    // above, so a failed/cancelled add is never recorded. Participates in
    // the existing date filter/search/trends like any other entry.
    unawaited(_log.logGrowthAdded(
      profile.name,
      entry.weightKg,
      entry.notes,
      petId: petId,
    ));
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Health / checkup records (PET-8) — add, edit (in place, same id) and
  // delete. Notes live inside the pet's own FullPetProfile, so they are
  // persisted to Hive and synced to Firestore by updateDetails like every
  // other profile change, and can never belong to another pet.
  // ─────────────────────────────────────────────────────────────────────────

  /// Pure list transform behind [updateHealthRecord]: replaces the note with
  /// [updated]'s id (never appends), keeps the list date-sorted. Returns
  /// null if no note has that id.
  @visibleForTesting
  static List<HealthRecord>? applyHealthRecordEdit(
    List<HealthRecord> records,
    HealthRecord updated,
  ) {
    if (!records.any((r) => r.id == updated.id)) return null;
    return [for (final r in records) r.id == updated.id ? updated : r]
      ..sort((a, b) => a.date.compareTo(b.date));
  }

  /// Pure list transform behind [deleteHealthRecord].
  @visibleForTesting
  static List<HealthRecord> applyHealthRecordDelete(
    List<HealthRecord> records,
    String recordId,
  ) =>
      records.where((r) => r.id != recordId).toList();

  /// Edits an existing checkup note in place (same id — never a duplicate).
  /// Activity History is an append-only log, so the original "added" entry is
  /// left as it was; the edit itself is recorded by updateDetails' normal
  /// profile-updated entry.
  Future<void> updateHealthRecord(
    String petId,
    HealthRecord updated,
  ) async {
    final profile = _getById(petId);
    if (profile == null) return;

    final records = applyHealthRecordEdit(profile.healthRecords, updated);
    if (records == null) return; // no such note on THIS pet — change nothing

    await updateDetails(profile.copyWith(healthRecords: records));
  }

  /// Deletes one checkup note from this pet. Past Activity History entries
  /// are deliberately kept (history is never rewritten).
  Future<void> deleteHealthRecord(
    String petId,
    String recordId,
  ) async {
    final profile = _getById(petId);
    if (profile == null) return;
    if (!profile.healthRecords.any((r) => r.id == recordId)) return;

    await updateDetails(
      profile.copyWith(
        healthRecords: applyHealthRecordDelete(profile.healthRecords, recordId),
      ),
    );
  }

  Future<void> addHealthRecord(
    String petId,
    HealthRecord record,
  ) async {
    final profile = _getById(petId);
    if (profile == null) return;

    final records = [...profile.healthRecords, record]
      ..sort((a, b) => a.date.compareTo(b.date));

    final careDays = _addDay(profile.careActivityDays, _dayKey(record.date));

    await updateDetails(
      profile.copyWith(healthRecords: records, careActivityDays: careDays),
    );

    unawaited(_log.logHealthRecord(
      profile.name,
      record.notes,
      petId: petId,
    ));
  }

  Future<void> updateGrowthEntry(
    String petId,
    GrowthEntry entry,
  ) async {
    final profile = _getById(petId);

    if (profile == null) return;

    final entries = profile.growthEntries
        .map(
          (e) => e.id == entry.id ? entry : e,
        )
        .toList();

    await updateDetails(
      profile.copyWith(
        growthEntries: entries,
        weightKg: entries.isEmpty ? '' : profile.weightKg,
      ),
    );
  }

  Future<void> deleteGrowthEntry(
    String petId,
    String entryId,
  ) async {
    final profile = _getById(petId);

    if (profile == null) return;

    final entries = profile.growthEntries
        .where(
          (e) => e.id != entryId,
        )
        .toList();

    await updateDetails(
      profile.copyWith(
        growthEntries: entries,
        weightKg: entries.isEmpty ? '' : profile.weightKg,
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Vaccination CRUD
  // ─────────────────────────────────────────────────────────────────────────

  Future<void> addVaccination(
    String petId,
    VaccinationRecord record, {
    bool logActivity = true,
  }) async {
    final profile = _getById(petId);

    if (profile == null) return;

    final vaccinations = [
      ...profile.vaccinations,
      record,
    ];

    final updated = profile.copyWith(
      vaccinations: vaccinations,
    );

    await updateDetails(updated);

    if (logActivity) {
      await _log.logVaccinationAdded(record.vaccineName, profile.name);
    }

    if (record.status == 'completed') {
      await _checkVaccinationAchievements(petId);
    }
  }

  Future<void> updateVaccination(
    String petId,
    VaccinationRecord record, {
    bool logActivity = true,
  }) async {
    final profile = _getById(petId);

    if (profile == null) return;

    final vaccinations = profile.vaccinations
        .map(
          (v) => v.id == record.id ? record : v,
        )
        .toList();

    await updateDetails(
      profile.copyWith(
        vaccinations: vaccinations,
      ),
    );

    if (logActivity) {
      await _log.logVaccinationUpdated(record.vaccineName, profile.name);
    }
  }

  Future<void> deleteVaccination(
    String petId,
    String vaccinationId, {
    bool logActivity = true,
  }) async {
    final profile = _getById(petId);

    if (profile == null) return;

    VaccinationRecord? removed;
    for (final v in profile.vaccinations) {
      if (v.id == vaccinationId) {
        removed = v;
        break;
      }
    }

    final vaccinations = profile.vaccinations
        .where(
          (v) => v.id != vaccinationId,
        )
        .toList();

    await updateDetails(
      profile.copyWith(
        vaccinations: vaccinations,
      ),
    );

    if (logActivity && removed != null) {
      await _log.logVaccinationDeleted(removed.vaccineName, profile.name);
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Complete vaccination dose
  // ─────────────────────────────────────────────────────────────────────────

  /// Completes one vaccination dose.
  ///
  /// NON-SERIES:
  ///
  /// Old pending record:
  ///     pending -> completed history
  ///
  /// Its reminder:
  ///     pending -> DONE
  ///
  /// A NEW vaccination record is created for the newly completed dose.
  ///
  /// If [nextSchedule] exists and reminders are enabled,
  /// another reminder is created and linked to the NEW record.
  ///
  /// SERIES:
  ///
  /// The upcoming record itself becomes completed.
  /// Its reminder becomes DONE.
  /// The reminder remains in the Done tab.
  ///
  /// The next dose already exists, so we do NOT create another one.

  /// Checks/unlocks Vaccine Hero and Vaccination Complete for one specific
  /// pet. Must be called AFTER the triggering vaccination update has
  /// already been persisted, so it re-fetches the pet fresh.
  ///
  /// [seriesId]/[totalDosesInSeries] should be the values from the dose
  /// that was JUST marked given — pass null for non-series doses, which
  /// simply skips the series check.
  Future<void> _checkVaccinationAchievements(
    String petId, {
    String? seriesId,
    int? totalDosesInSeries,
  }) async {
    final profile = _getById(petId);

    if (profile == null) return;

    final completedCount =
        profile.vaccinations.where((v) => v.status == 'completed').length;

    var achievements = await _unlockAndLog(
      profile.achievements,
      AchievementType.vaccinationComplete,
      completedCount,
      profile.name,
    );

    achievements = await _unlockAndLog(
      achievements,
      AchievementType.vaccinationKeeper,
      completedCount,
      profile.name,
    );

    if (seriesId != null && totalDosesInSeries != null) {
      final completedInSeries = profile.vaccinations
          .where(
            (v) => v.seriesId == seriesId && v.status == 'completed',
          )
          .length;

      achievements = await _unlockAndLog(
        achievements,
        AchievementType.vaccinationSeriesComplete,
        completedInSeries >= totalDosesInSeries ? 1 : 0,
        profile.name,
      );
    }

    final careDays = _addDay(
      profile.careActivityDays,
      _dayKey(DateTime.now()),
    );

    achievements = await _unlockAndLog(
      achievements,
      AchievementType.weekOfCare,
      careDays.length,
      profile.name,
    );

    await updateDetails(
      profile.copyWith(
        achievements: achievements,
        careActivityDays: careDays,
      ),
    );
  }

  Future<void> completeVaccinationDose(
    String petId,
    String oldRecordId, {
    required DateTime givenDate,
    DateTime? nextSchedule,
    bool reminderEnabled = false,
    ReminderProvider? reminderProvider,
  }) async {
    final pet = _getById(petId);

    if (pet == null) {
      return;
    }

    final old = _findVaccination(
      pet,
      oldRecordId,
    );

    if (old == null) {
      return;
    }

    // ───────────────────────────────────────────────────────────────────────
    // SERIES DOSE
    // ───────────────────────────────────────────────────────────────────────

    if (old.status == 'upcoming') {
      // Keep reminder in Done tab. logActivity: false — logVaccinationCompleted
      // below already records this exact same completion; logging it twice
      // (once as "reminder completed", once as "vaccination completed") for
      // one user action would be a duplicate Activity History entry.
      if (old.linkedReminderId != null && reminderProvider != null) {
        await reminderProvider.markReminderDone(
          old.linkedReminderId!,
          logActivity: false,
        );
      }

      // This dose is now complete.
      //
      // Clear the reminder link because the linked reminder is no longer
      // pending. The reminder itself remains in ReminderProvider's Done tab.
      final completed = old.copyWith(
        status: 'completed',
        completedDate: givenDate,
        nextSchedule: null,
        reminderEnabled: false,
        linkedReminderId: null,
      );

      await updateVaccination(
        petId,
        completed,
        logActivity: false,
      );

      await _log.logVaccinationCompleted(
        old.vaccineName,
        pet.name,
        wasPlanned: true,
      );

      await _checkVaccinationAchievements(
        petId,
        seriesId: old.seriesId,
        totalDosesInSeries: old.totalDosesInSeries,
      );

      return;
    }

    // ───────────────────────────────────────────────────────────────────────
    // NORMAL / NON-SERIES DOSE
    // ───────────────────────────────────────────────────────────────────────

    // Mark old reminder DONE. logActivity: false — see the same-named
    // parameter's use above; logVaccinationCompleted below is the single
    // Activity History entry for this completion.
    if (old.linkedReminderId != null && reminderProvider != null) {
      await reminderProvider.markReminderDone(
        old.linkedReminderId!,
        logActivity: false,
      );
    }

    // The old pending record becomes historical.
    //
    // We clear its pending schedule and reminder relationship.
    final historical = old.copyWith(
      nextSchedule: null,
      reminderEnabled: false,
      linkedReminderId: null,
    );

    await updateVaccination(
      petId,
      historical,
      logActivity: false,
    );

    // Create a completely NEW record for this completed dose.
    final newRecordId = _uuid.v4();

    String? newReminderId;

    // Create next-dose reminder if requested.
    if (nextSchedule != null && reminderEnabled && reminderProvider != null) {
      newReminderId = _uuid.v4();

      await reminderProvider.addReminder(
        ReminderItem(
          id: newReminderId,
          title: "💉 ${old.vaccineName} — ${pet.name}'s next dose",
          type: 'Vet Visit',
          scheduledAt: nextSchedule,
          petId: petId,
          linkedVaccinationId: newRecordId,
        ),
      );
    }

    final newRecord = VaccinationRecord(
      id: newRecordId,
      vaccineName: old.vaccineName,
      completedDate: givenDate,
      nextSchedule: nextSchedule,
      vetNotes: old.vetNotes,
      reminderEnabled:
          nextSchedule != null && reminderEnabled && reminderProvider != null,
      linkedReminderId: newReminderId,
      status: 'completed',
      recurrenceType: old.recurrenceType,
      recurrenceIntervalDays: old.recurrenceIntervalDays,
      seriesId: old.seriesId,
      doseNumber: old.doseNumber,
      totalDosesInSeries: old.totalDosesInSeries,
    );

    await addVaccination(
      petId,
      newRecord,
      logActivity: false,
    );

    await _log.logVaccinationCompleted(
      old.vaccineName,
      pet.name,
    );

    await _checkVaccinationAchievements(
      petId,
      seriesId: old.seriesId,
      totalDosesInSeries: old.totalDosesInSeries,
    );
  }

  VaccinationRecord? _findVaccination(
    FullPetProfile pet,
    String id,
  ) {
    for (final record in pet.vaccinations) {
      if (record.id == id) {
        return record;
      }
    }

    return null;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Vaccination series
  // ─────────────────────────────────────────────────────────────────────────

  /// Creates a bounded vaccination series.
  ///
  /// Example:
  ///
  /// FVRCP
  /// Dose 1 = Jan 1
  /// Dose 2 = Jan 22
  /// Dose 3 = Feb 12
  ///
  /// Each dose has:
  ///   • its own vaccination record ID
  ///   • its own reminder ID
  ///
  /// Therefore completing dose 2 can never accidentally complete dose 3.
  Future<void> addVaccinationSeries({
    required String petId,
    required String vaccineName,
    required DateTime firstGivenDate,
    required String vetNotes,
    required String recurrenceType,
    int? intervalDays,
    required int totalDoses,
    required bool reminderEnabled,
    ReminderProvider? reminderProvider,
  }) async {
    final pet = _getById(petId);

    if (pet == null) {
      return;
    }

    if (totalDoses < 1) {
      return;
    }

    final safeTotalDoses = totalDoses.clamp(1, 60);

    final safeInterval = (intervalDays ?? 7).clamp(1, 3650);

    final seriesId = _uuid.v4();

    final stepDays = recurrenceType == 'annual' ? 365 : safeInterval;

    DateTime dateForDose(
      int doseIndex,
    ) {
      return firstGivenDate.add(
        Duration(
          days: stepDays * doseIndex,
        ),
      );
    }

    // ───────────────────────────────────────────────────────────────────────
    // DOSE 1
    // ───────────────────────────────────────────────────────────────────────

    await addVaccination(
      petId,
      VaccinationRecord(
        id: _uuid.v4(),
        vaccineName: vaccineName,
        completedDate: firstGivenDate,
        vetNotes: vetNotes,
        status: 'completed',
        recurrenceType: recurrenceType,
        recurrenceIntervalDays:
            recurrenceType == 'everyXDays' ? stepDays : null,
        seriesId: seriesId,
        doseNumber: 1,
        totalDosesInSeries: safeTotalDoses,
        nextSchedule: null,
        reminderEnabled: false,
        linkedReminderId: null,
      ),
      logActivity: false,
    );

    // ───────────────────────────────────────────────────────────────────────
    // DOSES 2..N
    // ───────────────────────────────────────────────────────────────────────

    for (var index = 1; index < safeTotalDoses; index++) {
      final recordId = _uuid.v4();

      final plannedDate = dateForDose(index);

      String? reminderId;

      if (reminderEnabled && reminderProvider != null) {
        reminderId = _uuid.v4();

        await reminderProvider.addReminder(
          ReminderItem(
            id: reminderId,
            title:
                "💉 $vaccineName — ${pet.name}'s dose ${index + 1} of $safeTotalDoses",
            type: 'Vet Visit',
            scheduledAt: plannedDate,
            petId: petId,
            linkedVaccinationId: recordId,
          ),
        );
      }

      await addVaccination(
        petId,
        VaccinationRecord(
          id: recordId,
          vaccineName: vaccineName,

          // For planned records this is the planned dose date.
          // `status: upcoming` is what tells the UI that it has not
          // actually been administered yet.
          completedDate: plannedDate,

          nextSchedule: null,

          vetNotes: vetNotes,

          reminderEnabled: reminderId != null,

          linkedReminderId: reminderId,

          status: 'upcoming',

          recurrenceType: recurrenceType,

          recurrenceIntervalDays:
              recurrenceType == 'everyXDays' ? stepDays : null,

          seriesId: seriesId,

          doseNumber: index + 1,

          totalDosesInSeries: safeTotalDoses,
        ),
        logActivity: false,
      );
    }

    await _log.logVaccinationSeriesCreated(
      vaccineName,
      pet.name,
      safeTotalDoses,
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Activity counters
  // ─────────────────────────────────────────────────────────────────────────

  Future<void> incrementFeedCount(
    String petId,
  ) async {
    await _incrementCounter(
      petId,
      ActionType.feed,
    );
  }

  Future<void> incrementGroomCount(
    String petId,
  ) async {
    await _incrementCounter(
      petId,
      ActionType.groom,
    );
  }

  Future<void> incrementPlayCount(
    String petId,
  ) async {
    await _incrementCounter(
      petId,
      ActionType.play,
    );
  }

  Future<void> _incrementCounter(
    String petId,
    ActionType type,
  ) async {
    final profile = _getById(petId);

    if (profile == null) {
      return;
    }

    var feed = profile.feedCount;
    var groom = profile.groomCount;
    var play = profile.playCount;

    var achievements = List.of(profile.achievements);

    switch (type) {
      case ActionType.feed:
        feed++;

        achievements = _unlockAchievement(
          achievements,
          AchievementType.feedStreak,
          feed,
        );
        break;

      case ActionType.groom:
        groom++;

        achievements = _unlockAchievement(
          achievements,
          AchievementType.groomStreak,
          groom,
        );
        break;

      case ActionType.play:
        play++;

        achievements = _unlockAchievement(
          achievements,
          AchievementType.playStreak,
          play,
        );
        break;
    }

    await updateDetails(
      profile.copyWith(
        feedCount: feed,
        groomCount: groom,
        playCount: play,
        achievements: achievements,
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Achievements
  // ─────────────────────────────────────────────────────────────────────────

  List<PetAchievement> _unlockAchievement(
    List<PetAchievement> achievements,
    AchievementType type,
    int progress,
  ) {
    return achievements.map((achievement) {
      if (achievement.type != type) {
        return achievement;
      }

      final updated = achievement.copyWith(
        progressCurrent: progress,
      );

      if (!achievement.unlocked && progress >= achievement.progressTarget) {
        return updated.copyWith(
          unlocked: true,
          unlockedAt: DateTime.now(),
        );
      }

      return updated;
    }).toList();
  }

  /// Runs [_unlockAchievement] and, if it actually flips the achievement
  /// from locked → unlocked (not just a progress update), logs exactly one
  /// ActivityLogService entry for that specific pet.
  Future<List<PetAchievement>> _unlockAndLog(
    List<PetAchievement> achievements,
    AchievementType type,
    int progress,
    String petName,
  ) async {
    final before = achievements.firstWhere((a) => a.type == type).unlocked;

    final updated = _unlockAchievement(
      achievements,
      type,
      progress,
    );

    final after = updated.firstWhere((a) => a.type == type).unlocked;

    if (!before && after) {
      final title = updated.firstWhere((a) => a.type == type).title;

      await _log.logAchievementUnlocked(title, petName);
    }

    return updated;
  }

  /// Re-evaluates the "Profile Complete" achievement against [profile]'s
  /// current field values. Safe to call on every save (createProfile AND
  /// updateDetails) since it's a pure function of already-stored fields —
  /// no extra counters needed.
  Future<List<PetAchievement>> _checkProfileComplete(
    FullPetProfile profile,
  ) {
    final isComplete = profile.birthday.trim().isNotEmpty &&
        (profile.currentWeightKg ?? 0) > 0 &&
        profile.furColor.trim().isNotEmpty &&
        profile.adoptionDate.trim().isNotEmpty;

    return _unlockAndLog(
      profile.achievements,
      AchievementType.profileComplete,
      isComplete ? 1 : 0,
      profile.name,
    );
  }

  String _dayKey(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  List<String> _addDay(List<String> days, String key) =>
      days.contains(key) ? days : [...days, key];

  /// Checks/unlocks Grooming Pro, Healthy Eater, and Care Champion for one
  /// specific pet, based on that pet's own real-pet reminder completions.
  /// Reads directly from the existing persisted [ReminderItem] records
  /// (via [LocalStorageService]) rather than a separate counter, and
  /// counts ONLY reminders belonging to this [petId].
  ///
  /// Called from the reminder-completion action in the UI layer (not from
  /// ReminderProvider itself, to avoid a circular import between the two
  /// provider files).
  Future<void> checkCareAchievements(String petId) async {
    final profile = _getById(petId);

    if (profile == null) return;

    final allReminders =
        await LocalStorageService.instance.fetchReminderItems();

    final doneForThisPet = allReminders.where(
      (r) => r.petId == petId && r.isDone,
    );

    final groomingCount =
        doneForThisPet.where((r) => r.type == 'Grooming').length;

    final feedingCount =
        doneForThisPet.where((r) => r.type == 'Feeding').length;

    const careTypes = {
      'Feeding',
      'Grooming',
      'Exercise',
      'Vitamins',
    };

    final careCount =
        doneForThisPet.where((r) => careTypes.contains(r.type)).length;

    final totalCompleted = doneForThisPet.length;

    final today = _dayKey(DateTime.now());
    final reminderDays = _addDay(profile.reminderCompletionDays, today);
    final careDays = _addDay(profile.careActivityDays, today);

    var achievements = await _unlockAndLog(
      profile.achievements,
      AchievementType.groomingCare,
      groomingCount,
      profile.name,
    );

    achievements = await _unlockAndLog(
      achievements,
      AchievementType.feedingCare,
      feedingCount,
      profile.name,
    );

    achievements = await _unlockAndLog(
      achievements,
      AchievementType.careChampion,
      careCount,
      profile.name,
    );

    achievements = await _unlockAndLog(
      achievements,
      AchievementType.responsibleHuman,
      totalCompleted,
      profile.name,
    );

    achievements = await _unlockAndLog(
      achievements,
      AchievementType.onSchedule,
      totalCompleted,
      profile.name,
    );

    achievements = await _unlockAndLog(
      achievements,
      AchievementType.careRoutine,
      reminderDays.length,
      profile.name,
    );

    achievements = await _unlockAndLog(
      achievements,
      AchievementType.weekOfCare,
      careDays.length,
      profile.name,
    );

    await updateDetails(
      profile.copyWith(
        achievements: achievements,
        reminderCompletionDays: reminderDays,
        careActivityDays: careDays,
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Cloud sync
  // ─────────────────────────────────────────────────────────────────────────

  Future<void> syncNow() async {
    if (!_auth.isAuthenticated) {
      return;
    }

    for (final profile in List<FullPetProfile>.from(_profiles)) {
      unawaited(
        _uploadToCloud(profile),
      );
    }

    await _downloadFromCloud();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Guest → account merge
  //
  // Mirrors AppProvider.mergeGuestDataWithCloud() / replaceLocalWithCloud(),
  // for the FullPetProfile data those two never touch. Called from the same
  // post-login "Sync Offline Progress?" prompt in login_screen.dart, so pet
  // profiles/vaccinations/growth records created as a guest aren't left
  // behind locally when the user creates or signs into an account.
  // ─────────────────────────────────────────────────────────────────────────

  /// "Merge Progress": push every local (guest) profile to this account's
  /// cloud data, then pull down whatever else already exists there.
  Future<void> pushGuestDataToCloud() async {
    await PetPhotoService.instance.uploadLocalPhotosForPets(
      _profiles.map((profile) => profile.id),
    );
    await syncNow();
  }

  /// "Use Cloud Data": discard local (guest) profiles without uploading
  /// them, then replace local state with whatever is in the cloud.
  Future<void> replaceLocalWithCloud() async {
    if (!_auth.isAuthenticated) {
      return;
    }

    final localProfiles = List<FullPetProfile>.from(_profiles);
    for (final profile in localProfiles) {
      await PetPhotoService.instance.removeLocalPhotosForPet(profile.id);
      await _deleteFromHive(profile.id);
    }
    _profiles = [];
    notifyListeners();

    await _downloadFromCloud();
  }

  /// Best-effort: attempts to push any queued 'pet_profile'/
  /// 'delete_pet_profile' ops now. Public wrapper around the existing
  /// private flush so callers outside this provider (e.g. AppProvider's
  /// sign-out orchestration) can request one without duplicating its
  /// logic. Safe to call regardless of auth/connectivity — it's already
  /// a no-op in those cases.
  Future<void> flushPendingOpsIfPossible() => _flushPendingOps();

  /// Clears this device's local FullPetProfile data (Hive box +
  /// in-memory list). Used when an authenticated session ends (sign-out
  /// or account deletion) so the next guest/account on this device never
  /// sees the departed account's pet profiles. Does NOT touch Firestore —
  /// the account's cloud data is untouched by this.
  Future<void> clearAllLocalData({bool clearDeletionTombstones = false}) async {
    // init() is idempotent — guarantees the Hive box is actually open
    // even if this provider was never used this session (e.g. a user who
    // signed in but never visited a pet-profile screen before signing
    // out again). A no-op if already initialized.
    await init();
    final profileKeys =
        _box.keys.where((key) => key != _deletedProfilesKey).toList();
    await Future.wait(profileKeys.map(_box.delete));
    if (clearDeletionTombstones) {
      _deletedProfileIds.clear();
      await _saveDeletedProfileIds();
    }
    _profiles = [];
    notifyListeners();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Helpers
  // ─────────────────────────────────────────────────────────────────────────

  FullPetProfile? _getById(
    String id,
  ) {
    for (final profile in _profiles) {
      if (profile.id == id) {
        return profile;
      }
    }

    return null;
  }

  FullPetProfile? getById(
    String id,
  ) {
    return _getById(id);
  }

  String generateId() {
    return _uuid.v4();
  }
}

enum ActionType {
  feed,
  groom,
  play,
}
