// screens/splash_screen.dart
//
// Shows the Persipal brand for ~2.4s, then goes to HomeScreen.
//
// SessionManager.init() (awaited in main() before runApp) always leaves a
// session in place by the time this navigates — a brand-new install gets
// an auto-created guest session rather than being routed to LoginScreen.
// The LoginScreen fallback below only matters if that invariant is ever
// broken. Firebase is NEVER awaited here.

import 'dart:async';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import '../game/splash.dart';
import '../services/auth_service.dart';
import '../services/session_manager.dart';
import 'home_screen.dart';
import 'login_screen.dart';
import 'verify_email_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<double> _scale;
  late Animation<double> _slide;

  late final SplashGame _splashGame;

  @override
  void initState() {
    super.initState();

    _splashGame = SplashGame();

    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);

    _scale = Tween<double>(begin: 0.82, end: 1.0).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: Curves.easeOutBack,
      ),
    );

    _slide = Tween<double>(begin: 28, end: 0).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: Curves.easeOut,
      ),
    );

    _ctrl.forward();

    Future.delayed(
      const Duration(milliseconds: 2800),
      _navigate,
    );
  }

  @override
  void dispose() {
    _splashGame.pauseEngine();
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _navigate() async {
    if (!mounted) return;

    await _ctrl.reverse();

    if (!mounted) return;

    final auth = AuthService.instance;
    final firebaseUser = auth.currentUser;
    final hasLocalAuthenticatedSession =
        SessionManager.instance.isAuthenticated;
    debugPrint(
      'Persipal: startup auth state: '
      'Firebase user ${firebaseUser == null ? 'not restored' : 'restored'}, '
      'local session ${hasLocalAuthenticatedSession ? 'authenticated' : 'guest/missing'}.',
    );

    // Firebase is authoritative when available. If it restored a user after
    // SessionManager's snapshot was read, reconcile the local session before
    // routing so a stale guest snapshot cannot send that user to LoginScreen.
    if (firebaseUser != null &&
        (!SessionManager.instance.isAuthenticated ||
            SessionManager.instance.userId != firebaseUser.uid)) {
      await SessionManager.instance.onFirebaseLogin(firebaseUser);
      if (!mounted) return;
    }

    // Catches an authenticated-but-unverified user reopening the app —
    // Firebase persists sign-in state locally regardless of verification,
    // so without this check they could bypass VerifyEmailScreen just by
    // restarting. Google sign-ins are never affected (already verified).
    final needsVerification = auth.needsEmailVerification;

    Widget destination;

    if (firebaseUser != null || SessionManager.instance.isAuthenticated) {
      destination = needsVerification
          ? const VerifyEmailScreen()
          : const HomeScreen();
    } else if (SessionManager.instance.restoredGuestSession) {
      // A guest who deliberately continued offline already chose to use the
      // app without an account. Restore that guest directly instead of
      // presenting the login-choice screen again on every cold start.
      destination = const HomeScreen();
    } else {
      // Show account choices for a fresh install or stale account session.
      // A returning guest session was routed directly to Home above.
      destination = const LoginScreen();
    }

    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 450),
        pageBuilder: (_, __, ___) => destination,
        transitionsBuilder: (_, anim, __, child) => FadeTransition(
          opacity: anim,
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFE6CC),
      body: Stack(
        children: [
          Positioned.fill(
            child: Opacity(
              opacity: 0.10,
              child: Image.asset(
                'assets/images/paws_bg.png',
                fit: BoxFit.cover,
              ),
            ),
          ),
          const Positioned(
            top: 56,
            left: 0,
            right: 0,
            child: Icon(
              Icons.pets,
              size: 40,
              color: Color(0xFFFF8C69),
            ),
          ),
          Center(
            child: AnimatedBuilder(
              animation: _ctrl,
              builder: (_, __) => FadeTransition(
                opacity: _fade,
                child: Transform.scale(
                  scale: _scale.value,
                  child: Transform.translate(
                    offset: Offset(0, _slide.value),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 240,
                          height: 240,
                          // Keep the sprite clean against the splash background.
                          // The old black shadow behind the entire game canvas
                          // made the cat look like it was inside a dark box.
                          child: RepaintBoundary(
                            child: SizedBox(
                              width: 240,
                              height: 240,
                              child: GameWidget(
                                game: _splashGame,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        const Text(
                          'PERSIPAL',
                          style: TextStyle(
                            fontSize: 34,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 3,
                            color: Color(0xFF7A3B1E),
                          ),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'Persian Cat Care Companion',
                          style: TextStyle(
                            fontSize: 13,
                            color: Color(0xFFAA7755),
                            fontStyle: FontStyle.italic,
                            letterSpacing: 0.4,
                          ),
                        ),
                        const SizedBox(height: 48),
                        SizedBox(
                          width: 26,
                          height: 26,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.5,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              const Color(0xFFFF8C69).withValues(alpha: 0.65),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          'Loading…',
                          style: TextStyle(
                            fontSize: 12,
                            color: Color(0xFFAA7755),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
