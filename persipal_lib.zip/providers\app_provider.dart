// lib/providers/app_provider.dart
//
// Central ChangeNotifier.  Offline-first architecture:
//   1. Every mutation hits LocalStorageService first (instant UI update)
//   2. FirebaseSyncService syncs to Firestore in background
//   3. App never waits for internet to start

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';
import '../services/local_storage_service.dart';
import '../services/firebase_sync_service.dart';
import '../services/auth_service.dart';
import '../services/connectivity_service.dart';
import '../services/session_manager.dart';
import '../services/activity_log_service.dart';
import '../services/lesson_progress_service.dart';
import '../services/pet_photo_service.dart';
import '../services/reward_service.dart';
import '../services/virtual_achievement_service.dart';
import 'pet_profile_provider.dart';
import 'reminder_provider.dart';
import 'virtual_pet_provider.dart';

class AppProvider extends ChangeNotifier {
  final _local = LocalStorageService.instance;
  final _sync = FirebaseSyncService.instance;
  final _auth = AuthService.instance;
  final _connectivity = ConnectivityService.instance;
  final _session = SessionManager.instance;
  final _activityLog = ActivityLogService.instance;
  final _uuid = const Uuid();

  /// Wired from main.dart to the real care-reminder owner. AppProvider owns
  /// the Settings record, but ReminderProvider owns care notification state.
  static Future<void> Function()? onNotificationSettingsChanged;

  // ── State ─────────────────────────────────────────────────────────────────

  List<PetModel> _pets = [];
  List<ReminderModel> _reminders = [];
  List<QuizResult> _quizzes = [];
  List<ActivityLogModel> _logs = []; // FIX: was missing
  AppSettings _settings = const AppSettings();
  PetModel? _selectedPet;
  bool _loading = true;
  bool _syncing = false;

  // ── Getters ───────────────────────────────────────────────────────────────

  List<PetModel> get pets => List.unmodifiable(_pets);
  List<ReminderModel> get reminders => List.unmodifiable(_reminders);
  List<QuizResult> get quizzes => List.unmodifiable(_quizzes);
  List<ActivityLogModel> get logs => List.unmodifiable(_logs); // FIX: added
  AppSettings get settings => _settings;
  PetModel? get selectedPet => _selectedPet;
  bool get loading => _loading;
  bool get syncing => _syncing;
  bool get hasPets => _pets.isNotEmpty;
  SyncState get syncState => _sync.state;
  DateTime? get lastSyncAt => _sync.lastSyncAt;
  bool get isOnline => _connectivity.isOnline;
  bool get isGuest => _session.isGuest;
  bool get isAuthenticated => _session.isAuthenticated;
  String get displayName => _session.displayName;

  // Reminder helpers
  List<ReminderModel> get pendingReminders =>
      _reminders.where((r) => !r.isCompleted).toList()
        ..sort((a, b) => a.scheduledTime.compareTo(b.scheduledTime));

  List<ReminderModel> get completedReminders =>
      _reminders.where((r) => r.isCompleted).toList()
        ..sort((a, b) => b.scheduledTime.compareTo(a.scheduledTime));

  List<ReminderModel> get overdueReminders =>
      _reminders.where((r) => r.isOverdue).toList();

  int get pendingReminderCount => pendingReminders.length;

  // ── Init ──────────────────────────────────────────────────────────────────

  Future<void> init() async {
    _loading = true;
    notifyListeners();

    // Step 1: Load all data from Hive (always, regardless of connectivity)
    _pets = await _local.fetchPets();
    _reminders = await _local.fetchReminders();
    _settings = await _local.fetchSettings();
    _quizzes = await _local.fetchQuizResults();
    _logs = await _local.fetchLogs(); // FIX: populate logs on init

    // Step 2: Restore selected pet
    final savedId = await _local.getSelectedPetId();
    _selectedPet = _pets.isEmpty
        ? null
        : _pets.firstWhere(
            (p) => p.id == savedId,
            orElse: () => _pets.first,
          );

    // Step 3: Open app immediately
    _loading = false;
    notifyListeners();

    // Step 4: Wire up reactive listeners
    _connectivity.addListener(_onConnectivityChanged);
    _auth.addListener(_onAuthChanged);
    _sync.addListener(notifyListeners);

    // Step 5: Background cloud sync (non-blocking)
    unawaited(_backgroundSync());
  }

  @override
  void dispose() {
    _connectivity.removeListener(_onConnectivityChanged);
    _auth.removeListener(_onAuthChanged);
    _sync.removeListener(notifyListeners);
    super.dispose();
  }

  // ── Reactive listeners ────────────────────────────────────────────────────

  void _onConnectivityChanged() {
    if (_connectivity.isOnline && _auth.accountSyncAllowed) {
      unawaited(_backgroundSync());
    } else {
      _sync.markOffline();
    }
    notifyListeners();
  }

  void _onAuthChanged() {
    if (_auth.isAuthenticated && _auth.accountSyncAllowed) {
      unawaited(_backgroundSync());
    } else {
      // Signed out — clear the stale sync status (e.g. a leftover
      // "Synced"/"Sync failed" from the previous account) rather than
      // leaving it showing after there's no longer an authenticated
      // account to have synced.
      _sync.markIdle();
    }
    notifyListeners();
  }

  // ── Background sync ───────────────────────────────────────────────────────

  Future<void> _backgroundSync() async {
    if (!_auth.isAuthenticated || !_connectivity.isOnline) return;
    if (_syncing) return;
    _syncing = true;
    notifyListeners();
    try {
      // Flush any pending offline ops first
      await _sync.flushPendingOps(this);

      // Download cloud data and merge
      final cloud = await _sync.downloadAll();
      if (!cloud.isEmpty) {
        await _mergeCloudData(cloud);
      } else {
        // First login on this device — push local data up
        await _pushToCloud();
      }
      await _activityLog.logSyncCompleted();
    } catch (_) {
      // Silent fail — app works offline
    } finally {
      _syncing = false;
      notifyListeners();
    }
  }

  Future<void> _pushToCloud() async {
    if (!_auth.isAuthenticated || !_connectivity.isOnline) return;
    try {
      final logs = await _local.fetchLogs();
      await _sync.uploadAll(
        pets: _pets,
        logs: logs,
        reminders: _reminders,
        settings: _settings,
        quizzes: _quizzes,
      );
    } catch (_) {}
  }

  /// Merge cloud data into local state using updatedAt timestamps.
  Future<void> _mergeCloudData(CloudData cloud) async {
    // Pets: prefer newer version by updatedAt
    final petMap = {for (final p in _pets) p.id: p};
    for (final cp in cloud.pets) {
      final local = petMap[cp.id];
      if (local == null || cp.updatedAt.isAfter(local.updatedAt)) {
        petMap[cp.id] = cp;
        await _local.savePet(cp);
      }
    }
    _pets = petMap.values.toList();

    // Reminders: union by id
    final rMap = {for (final r in _reminders) r.id: r};
    for (final cr in cloud.reminders) {
      if (!rMap.containsKey(cr.id)) {
        rMap[cr.id] = cr;
        await _local.saveReminder(cr);
      }
    }
    _reminders = rMap.values.toList();

    // Quizzes: union
    final qIds = {for (final q in _quizzes) q.id};
    for (final cq in cloud.quizzes) {
      if (!qIds.contains(cq.id)) {
        _quizzes.insert(0, cq);
        await _local.saveQuizResult(cq);
      }
    }

    // Settings: use cloud if newer
    if (cloud.settings != null) {
      final cs = cloud.settings!;
      if (cs.updatedAt.isAfter(_settings.updatedAt)) {
        final previous = _settings;
        _settings = cs;
        await _local.saveSettings(_settings);
        await _refreshCareNotificationsIfNeeded(previous, _settings);
      }
    }

    // Restore selected pet if cleared
    if (_selectedPet == null && _pets.isNotEmpty) {
      _selectedPet = _pets.first;
    }

    // Activity History: restore this account's cloud logs into local storage
    // (union by id — existing local records are never duplicated or
    // replaced), so history cleared locally at sign-out comes back on login.
    final localLogIds = {for (final l in await _local.fetchLogs()) l.id};
    for (final cl in cloud.logs) {
      if (!localLogIds.contains(cl.id)) {
        await _local.addLog(cl);
        localLogIds.add(cl.id);
      }
    }
    await _activityLog.reload();
    _logs = await _local.fetchLogs();

    notifyListeners();
  }

  // ── Manual sync ───────────────────────────────────────────────────────────

  Future<SyncResult> syncNow() async {
    if (!_auth.isAuthenticated) {
      return SyncResult.failed('Sign in to enable cloud sync.');
    }
    if (!_connectivity.isOnline) {
      return SyncResult.failed('No internet connection.');
    }
    await _backgroundSync();
    return _sync.lastSyncAt != null
        ? SyncResult.success(_sync.lastSyncAt!)
        : SyncResult.failed('Sync failed. Please try again.');
  }

  // ── Guest-to-account upgrade ──────────────────────────────────────────────

  Future<void> mergeGuestDataWithCloud() async {
    await _pushToCloud();
    await _activityLog.logGuestMerged();
    await _backgroundSync();
  }

  Future<void> replaceLocalWithCloud() async {
    final cloud = await _sync.downloadAll();
    if (cloud.isEmpty) return;

    final previousSettings = _settings;

    await _local.deleteAllPets();
    await _local.deleteAllReminders();
    await _local.clearLogs();

    for (final p in cloud.pets) {
      await _local.savePet(p);
    }
    for (final r in cloud.reminders) {
      await _local.saveReminder(r);
    }

    final logs = await _local.fetchLogs();
    for (final l in cloud.logs) {
      if (!logs.any((e) => e.id == l.id)) await _local.addLog(l);
    }

    _pets = cloud.pets;
    _reminders = cloud.reminders;
    if (cloud.settings != null) {
      _settings = cloud.settings!;
      await _local.saveSettings(_settings);
    }
    _selectedPet = _pets.isNotEmpty ? _pets.first : null;
    _logs = await _local.fetchLogs(); // FIX: refresh logs
    await _activityLog.reload();
    await _refreshCareNotificationsIfNeeded(previousSettings, _settings);
    notifyListeners();
  }

  // ── Account sign-out / deletion cleanup ───────────────────────────────────
  //
  // The reverse of the guest-upgrade methods above: when an authenticated
  // session ENDS, the local working data across all three local stores
  // (this provider's own, PetProfileProvider's full_pet_profiles, and the
  // given ReminderProvider's reminder_items) must be cleared so the next
  // guest/account on this device never sees the departed account's data.
  // Firestore/cloud data is never touched by either method below.

  /// Signs out of Firebase/Google, first making a best-effort attempt to
  /// push any pending sync operations while still authenticated+online —
  /// bounded by a short timeout so sign-out is never blocked indefinitely
  /// (e.g. the device happens to be offline right now) — then clears all
  /// local working data.
  ///
  /// [reminderProvider]/[virtualPetProvider] are passed in because, unlike
  /// PetProfileProvider, neither is a singleton reachable by this provider
  /// on its own — the caller (a widget) already has both via Provider.
  Future<void> signOutAndClearLocalData(
    ReminderProvider reminderProvider,
    VirtualPetProvider virtualPetProvider,
  ) async {
    if (_auth.isAuthenticated && _connectivity.isOnline) {
      try {
        await Future.wait([
          _sync.flushPendingOps(this),
          PetProfileProvider.instance.flushPendingOpsIfPossible(),
          PetPhotoService.instance.flushPendingCloudPhotosIfPossible(),
          reminderProvider.flushPendingOpsIfPossible(),
          virtualPetProvider.flushPendingOpsIfPossible(),
        ]).timeout(const Duration(seconds: 5));
      } catch (_) {
        // Offline, timed out, or a transient Firestore error — this is
        // best-effort only, never a precondition for signing out.
      }
    }

    await _auth.signOut(reason: 'settings_explicit_sign_out');
    // keepPetPhotos: true — unlike everything else cleared here, pet photos
    // have no cloud copy to restore from (see PetPhotoService's header
    // comment), so a plain sign-out must leave the files in place for this
    // same account to find again next time it signs in on this device.
    // Nothing exposes them to a different account in the meantime, since
    // that account's own pets never share these IDs.
    await _clearAllProviderLocalData(
      reminderProvider,
      virtualPetProvider,
      keepPetPhotos: true,
    );
  }

  /// Used after the account and its cloud data have already been
  /// deleted (Settings' "Delete Account") — there's nothing left to
  /// flush, so this skips straight to clearing local data.
  Future<void> clearAllLocalDataAfterAccountDeletion(
    ReminderProvider reminderProvider,
    VirtualPetProvider virtualPetProvider,
  ) =>
      _clearAllProviderLocalData(
        reminderProvider,
        virtualPetProvider,
        clearDeletionTombstones: true,
      );

  /// Clears every local store used at an account boundary (sign-out or
  /// account deletion). Each step runs independently —
  /// if one store's clear throws, the rest still run rather than leaving
  /// the device in a half-cleared state with some of the previous account's
  /// data still exposed. Any failure is surfaced via [debugPrint] only;
  /// this makes cleanup more resilient, it doesn't make it transactional
  /// (Hive/Firestore offer no cross-store transaction here).
  Future<void> _clearAllProviderLocalData(
    ReminderProvider reminderProvider,
    VirtualPetProvider virtualPetProvider, {
    bool keepPetPhotos = false,
    bool clearDeletionTombstones = false,
  }) async {
    final steps = <String, Future<void> Function()>{
      'local data': () => clearAllLocalData(keepPetPhotos: keepPetPhotos),
      'pet profiles': () => PetProfileProvider.instance.clearAllLocalData(
            clearDeletionTombstones: clearDeletionTombstones,
          ),
      'reminders': () => reminderProvider.clearAllLocalData(),
      'virtual pet': () => virtualPetProvider.clearAllLocalData(),
      if (!keepPetPhotos)
        'pet photos': () => PetPhotoService.instance.clearAll(),
    };
    for (final entry in steps.entries) {
      try {
        await entry.value();
      } catch (e) {
        debugPrint('AppProvider: failed to clear ${entry.key}: $e');
      }
    }
    // In-memory-only resets never throw — no try/catch needed.
    LessonProgressService.instance.resetInMemory();
    RewardService.instance.resetInMemory();
    VirtualAchievementService.instance.resetInMemory();
  }

  // ── Pet CRUD ──────────────────────────────────────────────────────────────

  Future<void> addPet(PetModel pet) async {
    _pets.add(pet);
    if (_selectedPet == null) {
      _selectedPet = pet;
      await _local.setSelectedPetId(pet.id);
    }
    await _local.savePet(pet);
    unawaited(_sync.savePet(pet));
    await _activityLog.logProfileAdded(pet.name);
    _logs = await _local.fetchLogs(); // FIX: keep logs in sync
    notifyListeners();
  }

  Future<void> updatePet(PetModel pet) async {
    final idx = _pets.indexWhere((p) => p.id == pet.id);
    if (idx < 0) return;
    _pets[idx] = pet;
    if (_selectedPet?.id == pet.id) _selectedPet = pet;
    await _local.savePet(pet);
    unawaited(_sync.savePet(pet));
    notifyListeners();
  }

  Future<void> deletePet(String petId) async {
    final name = _pets
        .firstWhere((p) => p.id == petId,
            orElse: () => PetModel(
                id: '',
                name: 'Unknown',
                createdAt: DateTime.now(),
                updatedAt: DateTime.now()))
        .name;
    _pets.removeWhere((p) => p.id == petId);
    if (_selectedPet?.id == petId) {
      _selectedPet = _pets.isNotEmpty ? _pets.first : null;
      if (_selectedPet != null) {
        await _local.setSelectedPetId(_selectedPet!.id);
      } else {
        await _local.clearSelectedPetId();
      }
    }
    await _local.deletePet(petId);
    unawaited(_sync.deletePet(petId));
    await _activityLog.logProfileDeleted(name);
    _logs = await _local.fetchLogs(); // FIX: keep logs in sync
    notifyListeners();
  }

  Future<void> selectPet(PetModel pet) async {
    _selectedPet = pet;
    await _local.setSelectedPetId(pet.id);
    notifyListeners();
  }

  // ── Virtual pet stat mutations ────────────────────────────────────────────

  Future<void> feedPet(String petId, String foodName,
      {required int hungerDelta,
      required int happinessDelta,
      int cleanlinessDelta = 0}) async {
    final pet = _petById(petId);
    if (pet == null) return;
    final updated = pet.copyWith(
      stats: pet.stats.copyWith(
        hunger: pet.stats.hunger + hungerDelta,
        happiness: pet.stats.happiness + happinessDelta,
        cleanliness: pet.stats.cleanliness + cleanlinessDelta,
      ),
      updatedAt: DateTime.now(),
    );
    await updatePet(updated);
    await _activityLog.logFeed(pet.name, foodName);
    _logs = await _local.fetchLogs(); // FIX: keep logs in sync
    notifyListeners();
  }

  Future<void> groomPet(String petId, String toolName,
      {required int cleanlinessDelta, int happinessDelta = 0}) async {
    final pet = _petById(petId);
    if (pet == null) return;
    final updated = pet.copyWith(
      stats: pet.stats.copyWith(
        cleanliness: pet.stats.cleanliness + cleanlinessDelta,
        happiness: pet.stats.happiness + happinessDelta,
      ),
      updatedAt: DateTime.now(),
    );
    await updatePet(updated);
    await _activityLog.logGroom(pet.name, toolName);
    _logs = await _local.fetchLogs(); // FIX: keep logs in sync
    notifyListeners();
  }

  Future<void> playWithPet(String petId, String activity,
      {required int happinessDelta,
      int hungerDelta = 0,
      int energyDelta = 0}) async {
    final pet = _petById(petId);
    if (pet == null) return;
    final updated = pet.copyWith(
      stats: pet.stats.copyWith(
        happiness: pet.stats.happiness + happinessDelta,
        hunger: pet.stats.hunger + hungerDelta,
        energy: pet.stats.energy + energyDelta,
      ),
      updatedAt: DateTime.now(),
    );
    await updatePet(updated);
    await _activityLog.logPlay(pet.name, activity);
    _logs = await _local.fetchLogs(); // FIX: keep logs in sync
    notifyListeners();
  }

  Future<void> tickDecay(String petId) async {
    final pet = _petById(petId);
    if (pet == null) return;
    final updated = pet.copyWith(
      stats: pet.stats.copyWith(
        hunger: pet.stats.hunger + 1,
        happiness: pet.stats.happiness - 1,
        cleanliness: pet.stats.cleanliness - 1,
        energy: pet.stats.energy - 1,
      ),
      updatedAt: DateTime.now(),
    );
    final idx = _pets.indexWhere((p) => p.id == petId);
    if (idx >= 0) _pets[idx] = updated;
    if (_selectedPet?.id == petId) _selectedPet = updated;
    await _local.savePet(updated); // no cloud push for frequent decay ticks
    notifyListeners();
  }

  // ── Reminders CRUD ────────────────────────────────────────────────────────

  Future<void> addReminder(ReminderModel reminder) async {
    _reminders.add(reminder);
    await _local.saveReminder(reminder);
    unawaited(_sync.saveReminder(reminder));
    await _activityLog.logReminderAdded(
      reminder.title,
      reminder.type,
    );
    _logs = await _local.fetchLogs(); // FIX: keep logs in sync
    notifyListeners();
  }

  Future<void> updateReminder(ReminderModel reminder) async {
    final idx = _reminders.indexWhere((r) => r.id == reminder.id);
    if (idx < 0) return;
    _reminders[idx] = reminder;
    await _local.saveReminder(reminder);
    unawaited(_sync.saveReminder(reminder));
    await _activityLog.logReminderEdited(reminder.title);
    _logs = await _local.fetchLogs(); // FIX: keep logs in sync
    notifyListeners();
  }

  Future<void> toggleReminder(String id) async {
    final idx = _reminders.indexWhere((r) => r.id == id);
    if (idx < 0) return;
    final updated =
        _reminders[idx].copyWith(isCompleted: !_reminders[idx].isCompleted);
    _reminders[idx] = updated;
    await _local.saveReminder(updated);
    unawaited(_sync.saveReminder(updated));
    if (updated.isCompleted) {
      await _activityLog.logReminderCompleted(
        updated.title,
      );
      _logs = await _local.fetchLogs(); // FIX: keep logs in sync
    }
    notifyListeners();
  }

  Future<void> deleteReminder(String id) async {
    final title = _reminders
        .firstWhere((r) => r.id == id, orElse: () => _reminders.first)
        .title;
    _reminders.removeWhere((r) => r.id == id);
    await _local.deleteReminder(id);
    unawaited(_sync.deleteReminder(id));
    await _activityLog.logReminderDeleted(title);
    _logs = await _local.fetchLogs(); // FIX: keep logs in sync
    notifyListeners();
  }

  // ── Quiz ──────────────────────────────────────────────────────────────────

  Future<void> saveQuizResult(int score, int total,
      {String topic = 'general'}) async {
    final result = QuizResult(
      id: _uuid.v4(),
      score: score,
      total: total,
      completedAt: DateTime.now(),
      topic: topic,
    );
    _quizzes.insert(0, result);
    await _local.saveQuizResult(result);
    unawaited(_sync.saveQuizResult(result));
    await _activityLog.logQuiz(score, total);
    _logs = await _local.fetchLogs(); // FIX: keep logs in sync
    notifyListeners();
  }

  // ── Settings ──────────────────────────────────────────────────────────────

  Future<void> updateSettings(AppSettings s) async {
    final previous = _settings;
    _settings = s;
    await _local.saveSettings(s);
    unawaited(_sync.saveSettings(s));
    await _refreshCareNotificationsIfNeeded(previous, s);
    notifyListeners();
  }

  Future<void> _refreshCareNotificationsIfNeeded(
    AppSettings previous,
    AppSettings next,
  ) async {
    if (previous.notificationsEnabled == next.notificationsEnabled) return;
    final refresh = onNotificationSettingsChanged;
    if (refresh == null) return;
    try {
      await refresh();
    } catch (e) {
      debugPrint('AppProvider: failed to refresh care notifications: $e');
    }
  }

  // ── Data management ───────────────────────────────────────────────────────

  Future<void> clearAllLocalData({bool keepPetPhotos = false}) async {
    await _local.clearAll(keepPetPhotos: keepPetPhotos);
    await _activityLog.clearAll();
    _logs.clear();
    _pets.clear();
    _reminders.clear();
    _quizzes.clear();
    _selectedPet = null;
    notifyListeners();
  }

  Future<Map<String, dynamic>> exportLocalData() => _local.exportAll();

  Future<void> importLocalData(Map<String, dynamic> data) async {
    await _local.importAll(data);
    await _reload();
  }

  Future<void> _reload() async {
    _pets = await _local.fetchPets();
    _reminders = await _local.fetchReminders();
    _settings = await _local.fetchSettings();
    _quizzes = await _local.fetchQuizResults();
    _logs = await _local.fetchLogs(); // FIX: reload logs too
    await _activityLog.reload();
    _selectedPet = _pets.isNotEmpty ? _pets.first : null;
    notifyListeners();
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  PetModel? _petById(String id) {
    try {
      return _pets.firstWhere((p) => p.id == id);
    } catch (_) {
      return null;
    }
  }

  String generateId() => _uuid.v4();
}
