// lib/screens/achievements_screen.dart
//
// Real-pet Achievements screen — shows ONE real pet's achievement
// progress (scope: real_pet, keyed by petId). Never shows Virtual Cat
// achievements — see virtual_achievements_screen.dart for that scope.

import 'package:flutter/material.dart';
import '../providers/pet_profile_provider.dart';
import '../models/pet_extended_models.dart';
import '../widgets/achievement_card.dart';

class AchievementsScreen extends StatefulWidget {
  final String petId;
  const AchievementsScreen({super.key, required this.petId});

  @override
  State<AchievementsScreen> createState() => _AchievementsScreenState();
}

class _AchievementsScreenState extends State<AchievementsScreen>
    with TickerProviderStateMixin, AchievementConfettiMixin {
  final _provider = PetProfileProvider.instance;
  late String _petId;

  @override
  void initState() {
    super.initState();
    _petId = widget.petId;
    _provider.addListener(_refresh);
  }

  @override
  void dispose() {
    disposeConfetti();
    _provider.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() => setState(() {});

  FullPetProfile? get _pet => _provider.getById(_petId);

  AchievementCardData _toCardData(PetAchievement a) => AchievementCardData(
        title: a.title,
        description: a.description,
        emoji: a.emoji,
        unlocked: a.unlocked,
        unlockedAt: a.unlockedAt,
        progressCurrent: a.progressCurrent,
        progressTarget: a.progressTarget,
      );

  void _showDetail(PetAchievement achievement) {
    if (achievement.unlocked && !showingConfetti) celebrate();
    showAchievementDetail(context, _toCardData(achievement));
  }

  // ── Pet selector (only shown when there's more than one real pet) ────────

  List<FullPetProfile> get _allPets => _provider.profiles;

  void _switchPet(int delta) {
    final pets = _allPets;
    final index = pets.indexWhere((p) => p.id == _petId);
    if (index < 0) return;
    final next = (index + delta) % pets.length;
    final wrapped = next < 0 ? pets.length - 1 : next;
    setState(() => _petId = pets[wrapped].id);
  }

  @override
  Widget build(BuildContext context) {
    final pet = _pet;
    if (pet == null) {
      return const Scaffold(body: Center(child: Text('Profile not found.')));
    }

    final achievements = pet.achievements;
    final unlocked = achievements.where((a) => a.unlocked).length;
    final total = achievements.length;
    final pets = _allPets;

    return Scaffold(
      backgroundColor: const Color(0xFFFFE6CC),
      body: Stack(children: [
        Positioned.fill(
            child: Opacity(
          opacity: 0.10,
          child: Image.asset('assets/images/paws_bg.png', fit: BoxFit.cover),
        )),

        SafeArea(
            child: Column(children: [
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 4, 16, 0),
            child: Row(children: [
              IconButton(
                icon: const Icon(Icons.arrow_back_ios_new, size: 20),
                onPressed: () => Navigator.pop(context),
              ),
              const Text('🏆 ', style: TextStyle(fontSize: 18)),
              const Expanded(
                child: Text('Achievements',
                    style:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFB347).withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '$unlocked/$total',
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFAA7755)),
                ),
              ),
            ]),
          ),

          // Real-pet selector — only meaningful when there's more than one
          if (pets.length > 1)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.chevron_left),
                    onPressed: () => _switchPet(-1),
                  ),
                  Text(
                    pet.name,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF4A2C1A)),
                  ),
                  IconButton(
                    icon: const Icon(Icons.chevron_right),
                    onPressed: () => _switchPet(1),
                  ),
                ],
              ),
            ),

          // Overall progress bar
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Overall Progress',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFFAA7755))),
                    Text(
                      total > 0 ? '${(unlocked / total * 100).round()}%' : '0%',
                      style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFFFB347)),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: total > 0 ? unlocked / total : 0,
                    minHeight: 10,
                    backgroundColor: const Color(0xFFFFB347).withValues(alpha: 0.18),
                    valueColor: const AlwaysStoppedAnimation(Color(0xFFFFB347)),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),

          // Grid
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 30),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.0,
              ),
              itemCount: achievements.length,
              itemBuilder: (_, i) => AchievementGridCard(
                achievement: _toCardData(achievements[i]),
                onTap: () => _showDetail(achievements[i]),
              ),
            ),
          ),
        ])),

        buildConfettiOverlay(),
      ]),
    );
  }
}
