// lib/services/reward_service.dart
//
// Reward points (capstone FR: "earn points by completing tasks, quizzes, and
// pet care activities" / "unlock features or content using earned rewards").
//
// Points are a LEDGER of one-time events, so a one-time activity can never
// be paid twice:
//   lesson:<type>      +10   first completion of a lesson
//   quiz:best          5 + 2 per correct answer of the BEST score so far —
//                      a retake only pays for improving on that best
//   care:<reminderId>  +3    each completed care reminder (once per reminder)
//   growth:<entryId>   +2    each recorded weigh-in (once per entry)
//   virtual:<date>     +1 per virtual-cat action, capped at 5 a day
// Spending: claiming "unlock <lesson> early" costs [lessonUnlockCost]; each
// claim is stored once, so it can't be claimed twice. points = earned - spent.
//
// Separate from real-pet achievements (which are untouched). Persisted in
// Hive (offline-first); when signed in it is merged with a single
// users/{uid}/settings/progress document (ledger max-per-key, claims/lessons
// union) so progress survives sign-out/sign-in and other devices.

import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

import '../models/virtual_pet_state.dart';
import 'auth_service.dart';
import 'connectivity_service.dart';
import 'lesson_progress_service.dart';
import 'local_storage_service.dart';

class RewardService extends ChangeNotifier {
  RewardService._();
  static final RewardService instance = RewardService._();

  static const lessonCompletePoints = 10;
  static const quizFirstBonus = 5;
  static const quizPointsPerCorrect = 2;
  static const carePoints = 3;
  static const growthPoints = 2;
  static const virtualDailyCap = 5;
  static const lessonUnlockCost = 25;

  final _local = LocalStorageService.instance;

  Map<String, int> _ledger = {};
  Set<String> _claimed = {};
  Map<String, int> _shopPurchases = {};
  Map<String, String> _equippedShopItems = {};
  int _medicineCount = 0;
  int _medicineSpent = 0;
  int _vaccineCount = 0;
  int _vaccineSpent = 0;

  int get medicineCount => _medicineCount;
  int get vaccineCount => _vaccineCount;
  static const int medicinePrice = 10;
  static const int vaccinePrice = 10;

  bool _syncing = false;
  bool _listening = false;

  int get earned => _ledger.values.fold(0, (a, b) => a + b);
  int get lessonSpent => _claimed.length * lessonUnlockCost;
  int get shopSpent =>
      _shopPurchases.values.fold(0, (a, b) => a + b) +
      _medicineSpent +
      _vaccineSpent;
  int get spent => lessonSpent + shopSpent;
  int get points => (earned - spent).clamp(0, 1 << 30);

  bool isShopItemPurchased(String itemId) => _shopPurchases.containsKey(itemId);

  /// Whether a one-time reward ledger key has already been recorded.
  bool hasAwardKey(String key) => _ledger.containsKey(key);

  Set<String> get purchasedShopItems =>
      Set.unmodifiable(_shopPurchases.keys.toSet());

  String? equippedShopItem(String slot) => _equippedShopItems[slot];

  Future<void> equipShopItem(String itemId, String slot) async {
    if (!_shopPurchases.containsKey(itemId)) return;
    _equippedShopItems = {..._equippedShopItems, slot: itemId};
    await _changed();
  }

  bool isLessonUnlockClaimed(String type) => _claimed.contains('lesson:$type');

  // ── Lifecycle ─────────────────────────────────────────────────────────────

  Future<void> init() async {
    _load();
    notifyListeners();
    if (!_listening) {
      _listening = true;
      AuthService.instance.addListener(_onAuthChanged);
      ConnectivityService.instance.addListener(_onAuthChanged);
    }
    if (AuthService.instance.accountSyncAllowed) {
      unawaited(syncProgress());
    }
  }

  void _onAuthChanged() {
    if (AuthService.instance.accountSyncAllowed) {
      unawaited(syncProgress());
    }
  }

  void _load() {
    try {
      final raw = _local.fetchRewardState();
      if (raw == null) {
        _ledger = {};
        _claimed = {};
        _shopPurchases = {};
        _equippedShopItems = {};
        _medicineCount = 0;
        _medicineSpent = 0;
        _vaccineCount = 0;
        _vaccineSpent = 0;
        return;
      }
      final m = jsonDecode(raw) as Map<String, dynamic>;
      _ledger = {
        for (final e in (m['ledger'] as Map? ?? {}).entries)
          e.key as String: (e.value as num).toInt(),
      };
      _claimed = {...((m['claimed'] as List?) ?? const []).cast<String>()};
      _shopPurchases = {
        for (final e in (m['shopPurchases'] as Map? ?? {}).entries)
          e.key as String: (e.value as num).toInt(),
      };
      _equippedShopItems = {
        for (final e in (m['equippedShopItems'] as Map? ?? {}).entries)
          e.key as String: e.value as String,
      };
      _medicineCount = (m['medicineCount'] as num?)?.toInt() ?? 0;
      _medicineSpent = (m['medicineSpent'] as num?)?.toInt() ?? 0;
      _vaccineCount = (m['vaccineCount'] as num?)?.toInt() ?? 0;
      _vaccineSpent = (m['vaccineSpent'] as num?)?.toInt() ?? 0;
    } catch (_) {
      _ledger = {};
      _claimed = {};
      _shopPurchases = {};
      _equippedShopItems = {};
      _medicineCount = 0;
      _medicineSpent = 0;
      _vaccineCount = 0;
      _vaccineSpent = 0;
    }
  }

  Future<void> _save() => _local.saveRewardState(jsonEncode({
        'ledger': _ledger,
        'claimed': _claimed.toList(),
        'shopPurchases': _shopPurchases,
        'equippedShopItems': _equippedShopItems,
        'medicineCount': _medicineCount,
        'medicineSpent': _medicineSpent,
        'vaccineCount': _vaccineCount,
        'vaccineSpent': _vaccineSpent,
      }));

  /// Called when local data is wiped during sign-out or account deletion so
  /// the in-memory copy doesn't outlive the persisted one.
  void resetInMemory() {
    if (_ledger.isEmpty && _claimed.isEmpty && _shopPurchases.isEmpty) return;
    _ledger = {};
    _claimed = {};
    _shopPurchases = {};
    notifyListeners();
  }

  /// Discards local points/claims AND persists the empty state (unlike
  /// [resetInMemory]). Pairs with LessonProgressService.discardLocal() for
  /// "Use Cloud Data" — call this, then [syncProgress] to pull the
  /// account's real cloud progress into what is now an empty local state.
  Future<void> discardLocal() async {
    _ledger = {};
    _claimed = {};
    _shopPurchases = {};
    _equippedShopItems = {};
    await _save();
    notifyListeners();
  }

  // ── Earning ───────────────────────────────────────────────────────────────

  /// Awards [pts] once for [key]. Returns the points actually added (0 if
  /// this event was already rewarded).
  Future<int> awardOnce(String key, int pts) async {
    if (_ledger.containsKey(key)) return 0;
    _ledger = {..._ledger, key: pts};
    await _changed();
    return pts;
  }

  /// Quiz completion, scoped per lesson topic ('general' for the mixed
  /// quiz). Pays 5 + 2/correct answer the first time a topic's quiz is
  /// completed, and after that only for beating that topic's previous best
  /// — so retaking a DIFFERENT lesson's quiz is never blocked by an
  /// unrelated topic's best score. Returns points added.
  Future<int> awardQuiz(int score, {String topic = 'general'}) async {
    final now = quizFirstBonus + quizPointsPerCorrect * score;
    final key = 'quiz:$topic:best';
    final before = _ledger[key] ?? 0;
    if (now <= before) return 0;
    _ledger = {..._ledger, key: now};
    await _changed();
    return now - before;
  }

  /// Virtual-cat care action: +1, up to [virtualDailyCap] a day, so the
  /// simulation can't be farmed. Independent of real-pet achievements.
  Future<void> awardVirtualAction({DateTime? now}) async {
    final d = now ?? DateTime.now();
    final key =
        'virtual:${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
    final cur = _ledger[key] ?? 0;
    if (cur >= virtualDailyCap) return;
    _ledger = {..._ledger, key: cur + 1};
    await _changed();
  }

  int? _lastVirtualTotal;

  /// Forwarded from main.dart on each VirtualPetProvider change (once
  /// loaded). Awards a (daily-capped) point only when the action counter
  /// rises by exactly one — never on start-up, decay ticks or cloud restores.
  void onVirtualPetChanged(VirtualPetState pet) {
    final total = pet.simFeedCount + pet.simGroomCount + pet.simPlayCount;
    final last = _lastVirtualTotal;
    _lastVirtualTotal = total;
    if (last != null && total == last + 1) {
      unawaited(awardVirtualAction());
    }
  }

  // ── Spending ──────────────────────────────────────────────────────────────

  /// Claims "unlock this lesson early". False if already claimed or not
  /// enough points.
  Future<bool> claimLessonUnlock(String type) async {
    final key = 'lesson:$type';
    if (_claimed.contains(key) || points < lessonUnlockCost) return false;
    _claimed = {..._claimed, key};
    await _changed();
    return true;
  }

  /// Purchases a shop item once and deducts its exact cost from the shared
  /// reward-point balance. Shop purchases are persisted with the same
  /// offline-first reward ledger, so the Shop uses the existing point system
  /// instead of creating a second currency.
  Future<bool> purchaseShopItem(String itemId, int cost) async {
    if (cost < 0 || _shopPurchases.containsKey(itemId) || points < cost) {
      return false;
    }
    _shopPurchases = {..._shopPurchases, itemId: cost};
    await _changed();
    return true;
  }

  /// Purchases one consumable medicine using the existing points balance.
  /// Unlike cosmetics, medicine can be purchased repeatedly and is not equipped.
  Future<bool> purchaseMedicine() async {
    if (points < medicinePrice) return false;
    _medicineCount += 1;
    _medicineSpent += medicinePrice;
    await _changed();
    return true;
  }

  /// Purchases a vaccine consumable for the virtual Persian cat.
  Future<bool> purchaseVaccine() async {
    if (points < vaccinePrice) return false;
    _vaccineCount += 1;
    _vaccineSpent += vaccinePrice;
    await _changed();
    return true;
  }

  /// Removes one vaccine only after a valid vaccine interaction succeeds.
  Future<bool> consumeVaccine() async {
    if (_vaccineCount <= 0) return false;
    _vaccineCount -= 1;
    await _changed();
    return true;
  }

  /// Removes one medicine only after a valid medicine interaction succeeds.
  Future<bool> consumeMedicine() async {
    if (_medicineCount <= 0) return false;
    _medicineCount -= 1;
    await _changed();
    return true;
  }

  Future<void> _changed() async {
    await _save();
    notifyListeners();
    unawaited(syncProgress());
  }

  // ── Cloud merge (best effort — never blocks or breaks offline use) ────────

  DocumentReference<Map<String, dynamic>>? get _doc {
    final auth = AuthService.instance;
    if (!auth.isAuthenticated) return null;
    return FirebaseFirestore.instance
        .collection('users')
        .doc(auth.userId)
        .collection('settings')
        .doc('progress');
  }

  Future<void> syncProgress() async {
    DocumentReference<Map<String, dynamic>>? doc;
    try {
      doc = _doc;
    } catch (_) {
      doc = null; // Firebase unavailable — stay purely local
    }
    if (doc == null || !ConnectivityService.instance.isOnline || _syncing) {
      return;
    }

    final uid = AuthService.instance.userId;
    final ownerUid = _local.fetchRewardProgressOwner();
    // Guest progress can migrate to the first account that successfully syncs.
    // Once the local ledger belongs to an account, never silently merge its
    // coins, claims, purchases, or equipped items into a different account.
    if (ownerUid != null && ownerUid != uid) {
      debugPrint('RewardService: account mismatch; sync paused.');
      return;
    }

    _syncing = true;
    try {
      final snap = await doc.get();
      final cloud = snap.data();
      final lessons = LessonProgressService.instance;
      if (cloud != null) {
        final cloudLedger = {
          for (final e in (cloud['ledger'] as Map? ?? {}).entries)
            e.key as String: (e.value as num).toInt(),
        };
        final merged = {..._ledger};
        cloudLedger.forEach((k, v) {
          if (v > (merged[k] ?? -1)) merged[k] = v;
        });
        _ledger = merged;
        _claimed = {
          ..._claimed,
          ...((cloud['claimed'] as List?) ?? const []).cast<String>(),
        };
        final cloudShopPurchases = {
          for (final e in (cloud['shopPurchases'] as Map? ?? {}).entries)
            e.key as String: (e.value as num).toInt(),
        };
        final mergedShopPurchases = {..._shopPurchases};
        cloudShopPurchases.forEach((k, v) {
          if (v >= 0 && !mergedShopPurchases.containsKey(k)) {
            mergedShopPurchases[k] = v;
          }
        });
        _shopPurchases = mergedShopPurchases;
        _medicineCount =
            (cloud['medicineCount'] as num?)?.toInt() ?? _medicineCount;
        _medicineSpent =
            (cloud['medicineSpent'] as num?)?.toInt() ?? _medicineSpent;
        _vaccineCount =
            (cloud['vaccineCount'] as num?)?.toInt() ?? _vaccineCount;
        _vaccineSpent =
            (cloud['vaccineSpent'] as num?)?.toInt() ?? _vaccineSpent;
        _equippedShopItems = {
          ..._equippedShopItems,
          for (final e in (cloud['equippedShopItems'] as Map? ?? {}).entries)
            e.key as String: e.value as String,
        };
        await lessons.mergeCompleted(
            ((cloud['lessons'] as List?) ?? const []).cast<String>());
        await _save();
        notifyListeners();
      }
      await doc.set({
        'ledger': _ledger,
        'claimed': _claimed.toList(),
        'shopPurchases': _shopPurchases,
        'equippedShopItems': _equippedShopItems,
        'medicineCount': _medicineCount,
        'medicineSpent': _medicineSpent,
        'vaccineCount': _vaccineCount,
        'vaccineSpent': _vaccineSpent,
        'lessons': lessons.completedTypes.toList(),
        'updatedAt': DateTime.now().toIso8601String(),
      });
      await _local.saveRewardProgressOwner(uid);
    } catch (e) {
      debugPrint('RewardService: progress sync failed: $e');
    } finally {
      _syncing = false;
    }
  }
}
